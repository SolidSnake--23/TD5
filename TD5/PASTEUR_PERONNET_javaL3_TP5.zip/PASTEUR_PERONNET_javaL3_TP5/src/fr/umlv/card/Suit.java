package fr.umlv.card;

public enum Suit {
	  CLUB, DIAMOND, HEART, SPADE
}